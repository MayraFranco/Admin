/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemabanco;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties; 
import java.sql.PreparedStatement;
import javax.swing.JComboBox;

/**
 *
 * @author Mariana
 */
public class Deposito extends javax.swing.JFrame {

    /**
     * Creates new form Deposito
     */
    public Deposito() {
        initComponents();
        estableceConexion();
        modelo_tabla();
        fillTabla();
        consultar_cuentas(jComboBoxCLABE);
    }
    Connection con;
    String pass = "postgres";
    String user = "postgres";
    
    ResultSet resultado = null;
    int filasel=0;
    int idsel=0;
    DefaultTableModel modelo = new DefaultTableModel();
    
        public void estableceConexion()
    {
         try{
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco",user,pass);
           //JOptionPane.showMessageDialog(null,"Conexion Realizada");
           
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Error conexion" + ex);
        }
    }
        
   public void modelo_tabla()
   {
       modelo.addColumn("num_Deposito");
       modelo.addColumn("CLABE");
       modelo.addColumn("nombre_Cliente");
       modelo.addColumn("monto");
       modelo.addColumn("clave_seguridad");
  
       jTable1.setModel(modelo);
   }
   
       public void limpia()
   {
       //TFClabe.setText(""); 
       jTextFieldMonto.setText("");
       jTextFieldClave.setText("");
      
    }
       
   public void fillTabla()
   {
       modelo.setRowCount(0);
       String datos[] = new String[5]; //campos de la tabla
       
       try{
           Statement at = con.createStatement();
           //ResultSet rs = at.executeQuery("SELECT clabe as clabe ,no_tarjeta as no_tarjeta,cl.nombre_cliente as cl.nombre_cliente,s.nombre_sucursal as s.nombre_sucursal,c.saldo as c.saldo" + "FROM BANCO.Cuenta as c" +"INNER JOIN BANCO.Cliente as cl" + "ON c.id_cliente = cl.id_cliente" + "inner join BANCO.sucursal as s on c.idsucursal=s.idsucursal "); // cambias a tu tabla
           // ResultSet rs = at.executeQuery("SELECT d.num_deposito,d.clabe, d.monto, d.clave_seguridad\n" +
            //"FROM BANCO.deposito as d inner join BANCO.cuenta as c on d.clabe=c.clabe");      
            //ResultSet rs = at.executeQuery("SELECT * FROM BANCO.deposito");
//Esto nos ayuda a resumir la sentencia
             ResultSet rs = at.executeQuery("SELECT num_deposito, clabe_cliente, v.nombre_cliente, monto, clave_seguridad FROM BANCO.deposito p INNER JOIN BANCO.cuenta s ON p.clabe_cliente= s.clabe INNER JOIN BANCO.cuenta c ON s.clabe = c.clabe INNER JOIN BANCO.cliente v ON v.id_cliente = c.id_cliente");
      
           while(rs.next())
           {
               datos[0] = rs.getString("num_deposito");
               datos[1] = rs.getString("CLABE_cliente");
               datos[2] = rs.getString("nombre_cliente");
               datos[3] = rs.getString("monto");
               datos[4] = rs.getString("clave_seguridad");
               modelo.addRow(datos);
           }
        // JOptionPane.showMessageDialog(rootPane,"Tabla actualizada");
           rs.close();
           at.close();
       }catch(Exception a){
           JOptionPane.showMessageDialog(rootPane,"No se pudo actualizar");
       }
   }

    public void consultar_cuentas(JComboBox jComboBoxCLABE)
    {
        java.sql.Connection conectar = null;    
        PreparedStatement pst = null;
        ResultSet result = null;
        String SSQL = "SELECT clabe,no_tarjeta,cl.nombre_cliente, c.saldo FROM banco.cuenta as c INNER JOIN banco.cliente as cl ON c.id_cliente = cl.id_cliente";
        try 
        {
            //Establecemos conexión con la BD 
            conectar = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco", user, pass);
            //Preparamos la consulta SQL
            pst = conectar.prepareStatement(SSQL);
            //Ejecutamos la consulta
            result = pst.executeQuery(); 
            //LLenamos nuestro ComboBox
            jComboBoxCLABE.addItem("Seleccione una opción");

            while(result.next())
            {
                jComboBoxCLABE.addItem(result.getString("clabe")+ "-" +result.getString("nombre_cliente"));

            }
        }
        catch (SQLException error) 
        {
            JOptionPane.showMessageDialog(null, error);
    
        }   
        finally
        {
            if(conectar!=null)
            {
                try
                {
                    conectar.close();
                    result.close();

                    conectar=null;
                    result=null;

                } 
                catch (SQLException error2) 
                {

                    JOptionPane.showMessageDialog(null, error2);
                }
            }

        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBoxCLABE = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldMonto = new javax.swing.JTextField();
        jTextFieldClave = new javax.swing.JTextField();
        jScrollDeposito = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Agregar = new javax.swing.JButton();
        jButtonModificar = new javax.swing.JButton();
        jButtonEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jComboBoxCLABE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxCLABEActionPerformed(evt);
            }
        });

        jLabel1.setText("CLABE");

        jLabel2.setText("Monto");

        jLabel3.setText("Clave de seguridad");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollDeposito.setViewportView(jTable1);

        Agregar.setText("Agregar");
        Agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarActionPerformed(evt);
            }
        });

        jButtonModificar.setText("Modificar");
        jButtonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonModificarActionPerformed(evt);
            }
        });

        jButtonEliminar.setText("Eliminar");
        jButtonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jComboBoxCLABE, 0, 88, Short.MAX_VALUE)
                    .addComponent(jTextFieldMonto)
                    .addComponent(jTextFieldClave))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(Agregar, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jButtonModificar, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addComponent(jButtonEliminar))
                .addGap(19, 19, 19))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addComponent(jScrollDeposito, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBoxCLABE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(Agregar))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextFieldMonto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButtonModificar)))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextFieldClave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButtonEliminar)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollDeposito, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarActionPerformed
        // TODO add your handling code here:
        try{
            String aux2=(String)jComboBoxCLABE.getSelectedItem();
            String [] cuenta=aux2.split("-");
           
            Statement st = con.createStatement();
            String sql = "INSERT INTO BANCO.deposito(clabe_cliente, monto, clave_seguridad)"
            + "VALUES('"+cuenta[0]+"', '"+jTextFieldMonto.getText()+"' ,'"+jTextFieldClave.getText()+"' )";

            st.executeUpdate(sql);
            st.close();
            //JOptionPane.showMessageDialog(null,"Se insertó correctamente");
            fillTabla();
            limpia();

        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al insertar"+e);
        }
    }//GEN-LAST:event_AgregarActionPerformed

    private void jButtonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonModificarActionPerformed
        // TODO add your handling code here:
          try{
             String aux2=(String)jComboBoxCLABE.getSelectedItem();
            String [] cuenta=aux2.split("-");
         
            Statement st = con.createStatement();
            int fila = jTable1.getSelectedRow();
            int id = Integer.parseInt(this.jTable1.getValueAt(fila,0).toString());
            String sql = "UPDATE BANCO.deposito SET num_transferencia = '"+ cuenta[0] +"' , monto = '" + jTextFieldMonto.getText() + "' ,clave_seguridad =  '" + jTextFieldClave.getText()+"'   WHERE num_Deposito =  '"+id+"' ";         
            st.executeUpdate(sql);
            st.close();
            fillTabla();
            limpia();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al modificar:"+e);
        }
    }//GEN-LAST:event_jButtonModificarActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        String aux2=(String)jComboBoxCLABE.getSelectedItem();
        String [] cliente=aux2.split("-");
 
        int col = jTable1.getSelectedRow();
       
        jTextFieldMonto.setText(jTable1.getModel().getValueAt(col, 3).toString());
        jTextFieldClave.setText(jTable1.getModel().getValueAt(col, 4).toString());
      
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButtonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarActionPerformed
        // TODO add your handling code here:
         try{
            Statement st = con.createStatement();
            int fila = jTable1.getSelectedRow();
            int id = Integer.parseInt(this.jTable1.getValueAt(fila,0).toString());

            String sql="DELETE FROM BANCO.deposito  WHERE num_deposito =  '"+id+"' ";
            st.executeUpdate(sql);
            st.close();
            fillTabla();

            limpia();
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Error al eliminar:"+e);
        }
    }//GEN-LAST:event_jButtonEliminarActionPerformed

    private void jComboBoxCLABEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxCLABEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxCLABEActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        fillTabla();
    }//GEN-LAST:event_formWindowActivated

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Deposito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Deposito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Deposito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Deposito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Deposito().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Agregar;
    private javax.swing.JButton jButtonEliminar;
    private javax.swing.JButton jButtonModificar;
    private javax.swing.JComboBox<String> jComboBoxCLABE;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollDeposito;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextFieldClave;
    private javax.swing.JTextField jTextFieldMonto;
    // End of variables declaration//GEN-END:variables
}
