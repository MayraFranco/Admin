/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemabanco;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties; 
import java.sql.PreparedStatement;
import javax.swing.JComboBox;

/**
 *
 * @author Mariana
 */
public class Prestamo extends javax.swing.JFrame {

    /**
     * Creates new form Prestamo
     */
    public Prestamo() {
        initComponents();
        estableceConexion();
        modelo_tabla();
        fillTabla();
        consultar_cuentas(jComboBoxCLABE);
        consulta_Suc(jComboBoxSucursal);
    }
     Connection con;
    String pass = "postgres";
    String user = "postgres";
    
    ResultSet resultado = null;
    int filasel=0;
    int idsel=0;
    DefaultTableModel modelo = new DefaultTableModel();
    
        public void estableceConexion()
    {
         try{
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco",user,pass);
           //JOptionPane.showMessageDialog(null,"Conexion Realizada");
           
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Error conexion" + ex);
        }
    }
        
   public void modelo_tabla()
   {
       modelo.addColumn("num_prestamo");
       modelo.addColumn("clabe");
       modelo.addColumn("nombre_cliente");
       modelo.addColumn("nombre_Sucursal");
       modelo.addColumn("fecha_solicitud");
       modelo.addColumn("fecha_aprobado");
       modelo.addColumn("monto");
       modelo.addColumn("interes");
       modelo.addColumn("fecha_pago");
       modelo.addColumn("estatus");
  
       jTablePrestamo.setModel(modelo);
   }
   
       public void limpia()
   {
       
       jTextFieldMonto.setText("");
       jTextFieldinteres.setText("");
      
    }
     public void fillTabla()
   {
       modelo.setRowCount(0);
       String datos[] = new String[10]; //campos de la tabla
       
       try{
           Statement at = con.createStatement();
           //ResultSet rs = at.executeQuery("SELECT clabe as clabe ,no_tarjeta as no_tarjeta,cl.nombre_cliente as cl.nombre_cliente,s.nombre_sucursal as s.nombre_sucursal,c.saldo as c.saldo" + "FROM BANCO.Cuenta as c" +"INNER JOIN BANCO.Cliente as cl" + "ON c.id_cliente = cl.id_cliente" + "inner join BANCO.sucursal as s on c.idsucursal=s.idsucursal "); // cambias a tu tabla
           // ResultSet rs = at.executeQuery("SELECT d.num_deposito,d.clabe, d.monto, d.clave_seguridad\n" +
            //"FROM BANCO.deposito as d inner join BANCO.cuenta as c on d.clabe=c.clabe");      
            //ResultSet rs = at.executeQuery("SELECT * FROM BANCO.prestamo");
//Esto nos ayuda a resumir la sentencia
            // ResultSet rs = at.executeQuery("SELECT num_deposito, clabe_cliente, v.nombre_cliente, monto, clave_seguridad FROM BANCO.deposito p INNER JOIN BANCO.cuenta s ON p.clabe_cliente= s.clabe INNER JOIN BANCO.cuenta c ON s.clabe = c.clabe INNER JOIN BANCO.cliente v ON v.id_cliente = c.id_cliente");
            ResultSet rs = at.executeQuery("SELECT numero_Prestamo, P.CLABE, V.nombre_Cliente, nombre_Sucursal, fecha_Solicitud, fecha_Aprobado, P.saldo, intereses, fecha_Pago, aprobado_rechazado  FROM BANCO.Prestamo P INNER JOIN BANCO.Sucursal S ON P.idSucursal = S.idSucursal INNER JOIN BANCO.Cuenta C ON P.CLABE = C.CLABE INNER JOIN BANCO.cliente V ON V.id_Cliente = C.id_Cliente");
            
           while(rs.next())
           {
              //datos[0] = rs.getString("numero_prestamo");
              datos[0] = rs.getString("numero_prestamo");
              datos[1] = rs.getString("clabe");
              datos[2] = rs.getString("nombre_cliente");
              datos[3] = rs.getString("nombre_sucursal");
              datos[4] = rs.getString("fecha_solicitud");
              datos[5] = rs.getString("fecha_aprobado");
              datos[6] = rs.getString("saldo");
              datos[7] = rs.getString("intereses");
              datos[8] = rs.getString("fecha_pago");
              datos[9] = rs.getString("aprobado_rechazado");
               modelo.addRow(datos);
           }
        //JOptionPane.showMessageDialog(rootPane,"Tabla actualizada");
           rs.close();
           at.close();
       }catch(Exception a){
           JOptionPane.showMessageDialog(rootPane,"No se pudo actualizar");
       }
   }    
     public void consultar_cuentas(JComboBox jComboBoxCLABE)
    {
        java.sql.Connection conectar = null;    
        PreparedStatement pst = null;
        ResultSet result = null;
        String SSQL = "SELECT clabe FROM Banco.cuenta ORDER BY clabe ASC";
        try 
        {
            //Establecemos conexión con la BD 
            conectar = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco", user, pass);
            //Preparamos la consulta SQL
            pst = conectar.prepareStatement(SSQL);
            //Ejecutamos la consulta
            result = pst.executeQuery(); 
            //LLenamos nuestro ComboBox
            jComboBoxCLABE.addItem("Seleccione una opción");

            while(result.next())
            {
                jComboBoxCLABE.addItem(result.getString("clabe"));

            }
        }
        catch (SQLException error) 
        {
            JOptionPane.showMessageDialog(null, error);
    
        }   
        finally
        {
            if(conectar!=null)
            {
                try
                {
                    conectar.close();
                    result.close();

                    conectar=null;
                    result=null;

                } 
                catch (SQLException error2) 
                {

                    JOptionPane.showMessageDialog(null, error2);
                }
            }

        }
    }
     
     public void consulta_Suc(JComboBox CBSucursal)
    {
        java.sql.Connection conectar = null;    
        PreparedStatement pst = null;
        ResultSet result = null;
        String SSQL = "SELECT idsucursal, nombre_sucursal FROM Banco.sucursal ORDER BY idsucursal ASC";
        
        try 
        {
            //Establecemos conexión con la BD 
            conectar = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco", user, pass);
            //Preparamos la consulta SQL
            pst = conectar.prepareStatement(SSQL);
            //Ejecutamos la consulta
            result = pst.executeQuery(); 
            //LLenamos nuestro ComboBox
            CBSucursal.addItem("Seleccione una opción");

            while(result.next())
            {
                CBSucursal.addItem(result.getString("idsucursal")+ "-"+result.getString("nombre_sucursal"));
                

            }
        }
        catch (SQLException error) 
        {
            JOptionPane.showMessageDialog(null, error);
    
        }   
        finally
        {
            if(conectar!=null)
            {
                try
                {
                    conectar.close();
                    result.close();

                    conectar=null;
                    result=null;

                } 
                catch (SQLException error2) 
                {

                    JOptionPane.showMessageDialog(null, error2);
                }
            }

        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jComboBoxCLABE = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jComboBoxSucursal = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jComboBoxEstatus = new javax.swing.JComboBox<>();
        jDateChooseraprobado = new com.toedter.calendar.JDateChooser();
        jDateChooserSolicitud = new com.toedter.calendar.JDateChooser();
        jDateChooserPago = new com.toedter.calendar.JDateChooser();
        jTextFieldMonto = new javax.swing.JTextField();
        jTextFieldinteres = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTablePrestamo = new javax.swing.JTable();
        jButtonAgregar = new javax.swing.JButton();
        Modificar = new javax.swing.JButton();
        jButtonEliminar = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jLabel1.setText("CLABE");
        jLabel1.setRequestFocusEnabled(false);

        jLabel2.setText("Sucursal");

        jLabel3.setText("Monto ");

        jLabel4.setText("Intereses");

        jLabel5.setText("Fecha solicitud");

        jLabel6.setText("Fecha aprobado");

        jLabel7.setText("Fecha pago");

        jLabel8.setText("Estatus");

        jComboBoxEstatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aprobado", "Rechazado" }));

        jTablePrestamo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTablePrestamo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePrestamoMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTablePrestamo);

        jButtonAgregar.setLabel("Agregar");
        jButtonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAgregarActionPerformed(evt);
            }
        });

        Modificar.setText("Modificar");
        Modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificarActionPerformed(evt);
            }
        });

        jButtonEliminar.setText("Eliminar");
        jButtonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(jDateChooseraprobado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jDateChooserSolicitud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel1))
                            .addGap(58, 58, 58)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jComboBoxCLABE, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBoxSucursal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(74, 74, 74)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonAgregar))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(82, 82, 82)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jTextFieldMonto, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextFieldinteres, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel7)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jDateChooserPago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel8))
                                .addGap(36, 36, 36)
                                .addComponent(jComboBoxEstatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 114, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Modificar)
                            .addComponent(jButtonEliminar))))
                .addGap(89, 89, 89))
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane3)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jComboBoxCLABE, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextFieldMonto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButtonAgregar)
                        .addComponent(jLabel3)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jComboBoxSucursal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4)
                        .addComponent(jTextFieldinteres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Modificar))
                    .addComponent(jLabel2))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jDateChooserSolicitud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jDateChooserPago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jButtonEliminar))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel8)
                        .addComponent(jDateChooseraprobado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel6)
                    .addComponent(jComboBoxEstatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAgregarActionPerformed
        // TODO add your handling code here:
         try{
            String aux2=(String)jComboBoxCLABE.getSelectedItem();
            String [] cuenta=aux2.split("-");
            String aux3=(String)jComboBoxSucursal.getSelectedItem();//solo selecciona el id del cliente y sucursal e ignora los nombres
            String [] sucursal=aux3.split("-");
            String aux4=(String)jComboBoxEstatus.getSelectedItem();
            String [] aprobado=aux4.split("-");
           
            Statement st = con.createStatement();
            String sql = "INSERT INTO BANCO.prestamo(clabe, idsucursal, fecha_solicitud, fecha_aprobado, saldo, intereses, fecha_pago, aprobado_rechazado)"
            + "VALUES('"+cuenta[0]+"','"+sucursal[0]+"', '"+jDateChooserSolicitud.getDate()+"' ,'"+jDateChooseraprobado.getDate()+"', '"+jTextFieldMonto.getText()+"', '"+jTextFieldinteres.getText()+"', '"+jDateChooserPago.getDate()+"', '"+aprobado[0]+"' )";

            st.executeUpdate(sql);
            st.close();
            //JOptionPane.showMessageDialog(null,"Se insertó correctamente");
            fillTabla();
            limpia();

        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al insertar"+e);
        }
    }//GEN-LAST:event_jButtonAgregarActionPerformed

    private void jButtonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarActionPerformed
        // TODO add your handling code here:
          try{
            Statement st = con.createStatement();
            int fila = jTablePrestamo.getSelectedRow();
            int id = Integer.parseInt(this.jTablePrestamo.getValueAt(fila,0).toString());

            String sql="DELETE FROM BANCO.prestamo  WHERE numero_prestamo =  '"+id+"' ";
            st.executeUpdate(sql);
            st.close();
            fillTabla();

            limpia();
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Error al eliminar:"+e);
        }
    }//GEN-LAST:event_jButtonEliminarActionPerformed

    private void jTablePrestamoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePrestamoMouseClicked
        // TODO add your handling code here:
  
        int col = jTablePrestamo.getSelectedRow();
       
        jTextFieldMonto.setText(jTablePrestamo.getModel().getValueAt(col, 6).toString());
        jTextFieldinteres.setText(jTablePrestamo.getModel().getValueAt(col, 7).toString());
       
    }//GEN-LAST:event_jTablePrestamoMouseClicked

    private void ModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificarActionPerformed
        // TODO add your handling code here:
            try{
             String aux2=(String)jComboBoxCLABE.getSelectedItem();
            String [] cuenta=aux2.split("-");
            String aux3=(String)jComboBoxSucursal.getSelectedItem();//solo selecciona el id del cliente y sucursal e ignora los nombres
            String [] sucursal=aux3.split("-");
            String aux4=(String)jComboBoxEstatus.getSelectedItem();//solo selecciona el id del cliente y sucursal e ignora los nombres
            String [] aprobado=aux4.split("-");
            
            Statement st = con.createStatement();
            int fila = jTablePrestamo.getSelectedRow();
            int id = Integer.parseInt(this.jTablePrestamo.getValueAt(fila,0).toString());
            String sql = "UPDATE BANCO.prestamo SET clabe = '"+ cuenta[0] +"' , idsucursal = '"+sucursal[0]+"', fecha_solicitud = '"+jDateChooserSolicitud.getDate()+"', fecha_aprobado = '"+jDateChooseraprobado.getDate()+"',  saldo = '" + jTextFieldMonto.getText() + "', intereses = '"+jTextFieldinteres.getText()+"' ,fecha_pago=  '" +jDateChooserPago.getDate()+"', aprobado_rechazado = '"+aprobado[0]+"'   WHERE numero_prestamo =  '"+id+"' ";         
            st.executeUpdate(sql);
            st.close();
            fillTabla();
            limpia();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al modificar:"+e);
        }
    }//GEN-LAST:event_ModificarActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        fillTabla();        // TODO add your handling code here:
    }//GEN-LAST:event_formWindowActivated

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Prestamo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Prestamo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Prestamo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Prestamo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Prestamo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Modificar;
    private javax.swing.JButton jButtonAgregar;
    private javax.swing.JButton jButtonEliminar;
    private javax.swing.JComboBox<String> jComboBoxCLABE;
    private javax.swing.JComboBox<String> jComboBoxEstatus;
    private javax.swing.JComboBox<String> jComboBoxSucursal;
    private com.toedter.calendar.JDateChooser jDateChooserPago;
    private com.toedter.calendar.JDateChooser jDateChooserSolicitud;
    private com.toedter.calendar.JDateChooser jDateChooseraprobado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTablePrestamo;
    private javax.swing.JTextField jTextFieldMonto;
    private javax.swing.JTextField jTextFieldinteres;
    // End of variables declaration//GEN-END:variables
}
