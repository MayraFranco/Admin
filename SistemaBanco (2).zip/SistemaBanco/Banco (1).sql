-- Database: SistemaBanco

-- DROP DATABASE "SistemaBanco";

CREATE DATABASE "SistemaBanco"
    WITH 
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'Spanish_Mexico.1252'
    LC_CTYPE = 'Spanish_Mexico.1252'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;
	
CREATE SCHEMA BANCO
CREATE TABLE BANCO.cliente(
	id_Cliente BIGSERIAL,
	nombre_Cliente VARCHAR(15) NOT NULL,
	telefono VARCHAR(15) NOT NULL,
	fecha_Nacimiento DATE NOT NULL,
	CONSTRAINT PK_CLIENTE PRIMARY KEY (id_Cliente)
	)
	
	CREATE TABLE BANCO.Sucursal(
	idSucursal BIGSERIAL,
	nombre_Sucursal VARCHAR(30) NOT NULL,
	ciudad VARCHAR(30) NOT NULL,
	activos FLOAT NOT NULL,
	CONSTRAINT PK_SUCURSAL PRIMARY KEY(idSucursal)
	)

CREATE TABLE BANCO.Cuenta(
	CLABE BIGSERIAL,
	no_Tarjeta BIGINT NOT NULL,
	id_Cliente BIGINT NOT NULL,
	idSucursal BIGINT NOT NULL,
	saldo BIGINT NOT NULL,
	CONSTRAINT PK_CUENTA PRIMARY KEY(CLABE),
	CONSTRAINT FK_CLIENTE FOREIGN KEY (id_Cliente) REFERENCES BANCO.cliente(id_Cliente),
	CONSTRAINT FK_SUCURSAL FOREIGN KEY (idSucursal) REFERENCES BANCO.Sucursal(idSucursal)
	)

CREATE TABLE BANCO.Prestamo(
	numero_Prestamo BIGSERIAL,
	CLABE BIGINT NOT NULL,
	idSucursal BIGINT NOT NULL,
	fecha_Solicitud DATE NOT NULL,
	fecha_Aprobado DATE NOT NULL,
	saldo BIGINT NOT NULL,
	intereses FLOAT NOT NULL,
	fecha_Pago DATE NOT NULL,
	aprobado_rechazado VARCHAR(10) NOT NULL,
	CONSTRAINT PK_PRESTAMO PRIMARY KEY(numero_Prestamo),
	CONSTRAINT FK_CUENTA FOREIGN KEY (CLABE) REFERENCES BANCO.Cuenta(CLABE),
	CONSTRAINT FK_SUCURSAL2 FOREIGN KEY (idSucursal) REFERENCES BANCO.Sucursal(idSucursal)
	)
	
CREATE TABLE BANCO.Pagos(
	id_Pago BIGSERIAL,
	numero_Prestamo BIGINT NOT NULL,
	fecha_Pago DATE NOT NULL,
	forma_Pago VARCHAR(20) NOT NULL,
	moneda VARCHAR(20) NOT NULL,
	monto BIGINT NOT NULL,
	sello_Pago BIT,
	CONSTRAINT PK_PAGOS PRIMARY KEY(id_Pago),
	CONSTRAINT FK_PRESTAMO FOREIGN KEY (numero_prestamo) REFERENCES BANCO.Prestamo(numero_prestamo)
	)
	
CREATE TABLE BANCO.TipoError(
	id_Error BIGSERIAL,
	nombre_Error VARCHAR(20) NOT NULL,
	CONSTRAINT PK_TIPOERROR PRIMARY KEY(id_Error)
	)
	CREATE TABLE BANCO.TipoTransacciones(
	id_Tipo BIGSERIAL,
	nombre_Tipo VARCHAR(30) NOT NULL,
	CONSTRAINT PK_TIPOTRANSACCIONES PRIMARY KEY(id_Tipo)
)

CREATE TABLE BANCO.Transferencia(
	num_Transferencia BIGSERIAL,
	codigo_Spei VARCHAR(30) NOT NULL,
	idSucursal BIGINT NOT NULL,
	id_Error BIGINT NOT NULL,
	id_Tipo BIGINT NOT NULL,
	CLABE_Origen BIGINT NOT NULL,
	CLABE_Destino BIGINT NOT NULL,
	monto BIGINT NOT NULL,
	CONSTRAINT PK_TRANSFERECIA PRIMARY KEY(num_Transferencia),
	CONSTRAINT FK_SUCURSAL1 FOREIGN KEY (idSucursal) REFERENCES BANCO.Sucursal(idSucursal),
	CONSTRAINT FK_TIPOERROR FOREIGN KEY (id_Error) REFERENCES BANCO.TipoError (id_Error),
	CONSTRAINT FK_TIPOTRANSACCIONES FOREIGN KEY (id_Tipo) REFERENCES BANCO.TipoTransacciones (id_Tipo),
	CONSTRAINT FK_CUENTA2 FOREIGN KEY (CLABE_Origen) REFERENCES BANCO.Cuenta(CLABE),
	CONSTRAINT FK_CUENTA3 FOREIGN KEY (CLABE_Destino) REFERENCES BANCO.Cuenta(CLABE)
	)
	
CREATE TABLE BANCO.Deposito(
	num_Deposito BIGSERIAL,
	CLABE_Cliente BIGINT NOT NULL,
	monto BIGINT NOT NULL,
	clave_Seguridad BIGINT NOT NULL, 
	CONSTRAINT PK_DEPOSITO PRIMARY KEY(num_Deposito),
	CONSTRAINT FK_CUENTA4 FOREIGN KEY (CLABE_Cliente) REFERENCES BANCO.Cuenta(CLABE)
	)




/***************************************************************** Restriccion check numérica*/
ALTER TABLE Banco.PAGOS
ADD CONSTRAINT VerificaPago
CHECK (monto>=0);

ALTER TABLE Banco.sucursal
ADD CONSTRAINT VerificaActivos
CHECK (activos>=0);


/***************************************************************** Restricción check cadenas */
ALTER TABLE Banco.sucursal
ADD CONSTRAINT VerificaSucursal
CHECK (nombre_sucursal = 'SucursalTangamanga' OR nombre_sucursal = 'SucursalDorado' OR nombre_sucursal ='SucursalSendero' OR nombre_sucursal = 'SucursalCentro') 

/****************************************************************** UNIQUE*/
ALTER TABLE BANCO.Cuenta 
ADD CONSTRAINT Unique_NTarjeta UNIQUE (no_Tarjeta) 


/*Inserciones */
INSERT INTO Banco.cliente (nombre_cliente, telefono, fecha_nacimiento ) VALUES ('Robi', '44412345678','01/05/2021') 
SELECT * FROM Banco.cliente
/*Salta el check porque el valor es -1 */
INSERT INTO Banco.pagos ( numero_prestamo, fecha_pago, forma_pago, moneda, monto, sello_pago)
VALUES (1,'01/05/2021','tarjeta','MXN',-1, '0')

/*Insercion correcta para el check*/
INSERT INTO Banco.pagos ( numero_prestamo, fecha_pago, forma_pago, moneda, monto, sello_pago)
VALUES (7,'01/05/2021','tarjeta','MXN',1, '0')

SELECT * FROM Banco.Prestamo


INSERT INTO Banco.Sucursal (nombre_sucursal, ciudad, activos) VALUES('SucursalTangamanga','San Luis Potosí', 1.0)
SELECT * FROM Banco.Sucursal

INSERT INTO Banco.transferencia(codigo_spei, idsucursal, id_error, id_tipo,clabe_origen, clabe_destino, monto) 
VALUES ('123456', 3, 1,1,3,4,500)
INSERT INTO Banco.tipoerror (nombre_error) VALUES ('EXITO')
INSERT INTO Banco.tipotransacciones(nombre_tipo) VALUES ('MISMO DIA')
SELECT * FROM Banco.cuenta
UPDATE Banco.prestamo SET saldo = 0 WHERE numero_prestamo = 5
DELETE FROM Banco.prestamo WHERE numero_prestamo = 2 /*Nos regresa al prestamo de la inserción*/

/********************************************************************TRIGGER 1**********************************************/
/***************************************** Que cuando el cliente haga un préstamo se actualice su saldo actual. ***********/
CREATE OR REPLACE FUNCTION actualizaSaldoTotal()
  RETURNS TRIGGER AS
$BODY$

BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE Banco.cuenta SET saldo = saldo + (NEW.saldo) WHERE clabe = NEW.clabe;
    ELSIF TG_OP = 'UPDATE' THEN
        UPDATE Banco.cuenta SET saldo = saldo - (OLD.saldo) WHERE clabe = OLD.clabe;
        UPDATE Banco.cuenta SET saldo = saldo + (NEW.saldo) WHERE clabe = NEW.clabe;
		
    ELSIF TG_OP = 'DELETE' THEN
       UPDATE Banco.cuenta SET saldo = saldo - (OLD.saldo) WHERE clabe = OLD.clabe;
	END IF;
 
    RETURN NULL;
END;
$BODY$
  LANGUAGE plpgsql;
  
  /*activacion*/ 
  /*After porque va después de haber dado el prestamo*/
CREATE TRIGGER actualizaSaldo AFTER INSERT OR UPDATE OR DELETE 
ON Banco.prestamo FOR EACH ROW
EXECUTE PROCEDURE actualizaSaldoTotal();


SELECT * FROM Banco.sucursal
INSERT INTO Banco.prestamo ( clabe, idsucursal, fecha_solicitud, fecha_aprobado, saldo, intereses, fecha_pago, aprobado_rechazado) VALUES 
(3, 3, '01/05/2020', '01/05/2021', 1000001, 3.0, '02/05/2021', 1)
SELECT * FROM Banco.prestamo

/********************************************************************TRIGGER 2***********************************************/
/*********************************** Cuando el cliente deposite se actualiza el campo saldo en Cuenta***********************/
/* 
CREATE OR REPLACE FUNCTION actualizaSaldoDeposito()
  RETURNS TRIGGER AS
$BODY$
DECLARE 
	getId BIGINT;

BEGIN
    IF TG_OP = 'INSERT' THEN
		getId = (SELECT clabe FROM Banco.prestamo WHERE numero_prestamo = NEW.numero_prestamo);
        UPDATE Banco.cuenta SET saldo = saldo - (NEW.monto) WHERE clabe = getId;
    ELSIF TG_OP = 'UPDATE' THEN
		getId = (SELECT clabe FROM Banco.prestamo WHERE numero_prestamo = NEW.numero_prestamo);
        UPDATE Banco.cuenta SET saldo = saldo + (OLD.monto) WHERE clabe = getId;
		getId = (SELECT clabe FROM Banco.prestamo WHERE numero_prestamo = OLD.numero_prestamo);
        UPDATE Banco.cuenta SET saldo = saldo - (NEW.monto) WHERE clabe = getId;
		
    ELSIF TG_OP = 'DELETE' THEN
	getId = (SELECT clabe FROM Banco.prestamo WHERE numero_prestamo = OLD.numero_prestamo);
       UPDATE Banco.cuenta SET saldo = saldo + (OLD.monto) WHERE clabe = getId; 
	END IF;
 
    RETURN NULL;
END;
$BODY$
  LANGUAGE plpgsql;
  
  /*activacion*/ 
CREATE TRIGGER actualizaSaldoDeposito AFTER INSERT OR UPDATE OR DELETE 
ON Banco.pagos FOR EACH ROW
EXECUTE PROCEDURE actualizaSaldoDeposito();
*/

/******************************************************* TRIGGER  3 *******************************/
/********************* Que de obtener un préstamo se actualicen los activos de la sucursal. *******/
CREATE OR REPLACE FUNCTION ActualizaActivos()
  RETURNS TRIGGER AS
$BODY$

BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE Banco.sucursal SET activos = activos - (NEW.saldo) WHERE idsucursal = NEW.idsucursal;
    ELSIF TG_OP = 'UPDATE' THEN
        UPDATE Banco.sucursal SET activos = activos + (OLD.saldo) WHERE idsucursal = OLD.idsucursal;
        UPDATE Banco.sucursal SET activos = activos - (NEW.saldo) WHERE idsucursal = NEW.idsucursal;
		
    ELSIF TG_OP = 'DELETE' THEN
       UPDATE Banco.sucursal SET activos = activos + (OLD.saldo) WHERE idsucursal = OLD.idsucursal;
	END IF;
 
    RETURN NULL;
END;
$BODY$
  LANGUAGE plpgsql;
  
  /*activacion*/ 
  /*After porque va después de haber dado el prestamo*/
CREATE TRIGGER actualizaActivos AFTER INSERT OR UPDATE OR DELETE 
ON Banco.prestamo FOR EACH ROW
EXECUTE PROCEDURE actualizaActivos();



/****************************************************** TRIGGER 4 y 5 **********************************************/
/*******************************  Que al hacer una transferencia el saldo del cliente se actualice. */
/*******************************  Que al hacer una obtener la transferenca  el saldo del cliente se actualice. */
CREATE OR REPLACE FUNCTION SaldoPorTransferencia()
  RETURNS TRIGGER AS
$BODY$

BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE Banco.cuenta SET saldo = saldo + (NEW.monto) WHERE clabe = NEW.clabe_destino;
		UPDATE Banco.cuenta SET saldo = saldo - (NEW.monto) WHERE clabe = NEW.clabe_origen;
    ELSIF TG_OP = 'UPDATE' THEN
        UPDATE Banco.cuenta SET saldo = saldo - (OLD.monto) WHERE clabe = OLD.clabe_destino;
        UPDATE Banco.cuenta SET saldo = saldo + (NEW.monto) WHERE clabe = NEW.clabe_destino;
		UPDATE Banco.cuenta SET saldo = saldo + (OLD.monto) WHERE clabe = OLD.clabe_origen;
        UPDATE Banco.cuenta SET saldo = saldo - (NEW.monto) WHERE clabe = NEW.clabe_origen;
    ELSIF TG_OP = 'DELETE' THEN
       UPDATE Banco.cuenta SET saldo = saldo - (OLD.monto) WHERE clabe = OLD.clabe_destino;
	   UPDATE Banco.cuenta SET saldo = saldo + (OLD.monto) WHERE clabe = OLD.clabe_origen;
	   
	END IF;
 
    RETURN NULL;
END;
$BODY$
  LANGUAGE plpgsql;
  
  /*activacion*/ 
  /*After porque va después de haber dado el prestamo*/
CREATE TRIGGER saldoPorTransferencia AFTER INSERT OR UPDATE OR DELETE 
ON Banco.transferencia FOR EACH ROW
EXECUTE PROCEDURE SaldoPorTransferencia();


/*************************************************** TRIGGER 6 ****************************************/
/* Cuando se liquide un préstamo el saldo de la deuda del cliente se actualice */
/*
CREATE OR REPLACE FUNCTION LiquidaDeuda()
  RETURNS trigger AS
$$
    DECLARE Subtotal FLOAT := 0.0;
    DECLARE vmontototal FLOAT :=0.0;
    DECLARE SUBTOTAL2 FLOAT :=0.0;
BEGIN
    SELECT SUM(pg.monto) INTO vmontototal FROM Banco.pagos pg  WHERE pg.numero_prestamo = NEW.numero_prestamo;
    UPDATE Banco.prestamo  SET saldo = saldo - vmontototal WHERE numero_prestamo = NEW.numero_prestamo; 
END
$$
LANGUAGE plpgsql;


/*Opcion 2*/

CREATE OR REPLACE FUNCTION LiquidaDeuda()
  RETURNS TRIGGER AS
$BODY$

BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE Banco.prestamo SET saldo = saldo - (NEW.monto) WHERE numero_prestamo = NEW.numero_prestamo;
    ELSIF TG_OP = 'UPDATE' THEN
        UPDATE Banco.prestamo SET saldo = saldo + (OLD.saldo) WHERE numero_prestamo = OLD.numero_prestamo;
        UPDATE Banco.prestamo SET saldo = saldo - (NEW.monto) WHERE numero_prestamo = NEW.numero_prestamo;
    ELSIF TG_OP = 'DELETE' THEN
       UPDATE Banco.prestamo SET saldo = saldo - (OLD.saldo) WHERE numero_prestamo = OLD.numero_prestamo;
	   
	END IF;
 
    RETURN NULL;
END;
$BODY$
  LANGUAGE plpgsql;
  
  /*activacion*/ 
  /*After porque va después de haber dado el prestamo*/
CREATE TRIGGER LiquidaDeuda AFTER INSERT OR UPDATE OR DELETE 
ON Banco.pagos FOR EACH ROW
EXECUTE PROCEDURE LiquidaDeuda();

INSERT INTO Banco.pagos ( numero_prestamo, fecha_pago, forma_pago, moneda, monto, sello_pago)
VALUES (7,'01/05/2021','tarjeta','MXN',10, '0')

SELECT * FROM Banco.Pagos
*/







