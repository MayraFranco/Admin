package sistemabanco;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class SistemaBanco {

    
    public static void main(String[] args) 
    {
     Connection conexion; 
     String pass = "postgres";
     String user = "postgres";
     
     try{
         conexion = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco", user, pass);
         JOptionPane.showMessageDialog(null, "Conexion realizada");
     }catch(SQLException ex)
     {
         JOptionPane.showMessageDialog(null, "ERROR"+ex);
     }
    }//fin main
}
