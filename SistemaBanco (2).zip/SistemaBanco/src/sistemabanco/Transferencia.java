/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemabanco;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
/**
/**
 *
 * @author mayra
 */
public class Transferencia extends javax.swing.JFrame {

    /**
     * Creates new form Transferencia
     */
    public Transferencia() {
        initComponents();
         estableceConexion();
        modelo_tabla();
        fillTabla();
        consultaTransaccion(CBTransaccion);
        consulta_Suc(CBSucursal);
        consultar_cuentas(CBOrigen,CBDestino);
        consultaError(CBTError);
        limpia();
    }
     Connection con;
    String pass = "postgres";
    String user = "postgres";
    ResultSet resultado = null;
    int filasel=0;
    int idsel=0;
    DefaultTableModel modelo = new DefaultTableModel();
public void estableceConexion()
    {
         try{
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco",user,pass);
          // JOptionPane.showMessageDialog(null,"Conexion Realizada");
           
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Error conexion" + ex);
        }
    }
public void modelo_tabla()
   {
       modelo.addColumn("num_transferencia");
       modelo.addColumn("codigo_spei");
       modelo.addColumn("idsucursal");
       modelo.addColumn("id_error");
       modelo.addColumn("id_tipo");
       modelo.addColumn("clabe_origen");
       modelo.addColumn("clabe_destino");
       modelo.addColumn("monto");

       TTransfer.setModel(modelo);
   }
public void limpia()
   {
       TFSpei.setText(""); 
       TFMonto.setText("");
    }
public void fillTabla()
   {
       modelo.setRowCount(0);
       String datos[] = new String[8]; //campos de la tabla
       
       try{
           Statement at = con.createStatement();
           ResultSet rs = at.executeQuery("SELECT * FROM BANCO.transferencia"); // cambias a tu tabla
           
           while(rs.next())
           {
               datos[0] = rs.getString("num_transferencia");
               datos[1] = rs.getString("codigo_spei");
               datos[2] = rs.getString("idsucursal");
               datos[3] = rs.getString("id_error");
               datos[4] = rs.getString("id_tipo");
               datos[5] = rs.getString("clabe_origen");
               datos[6] = rs.getString("clabe_destino");
               datos[7] = rs.getString("monto");
               modelo.addRow(datos);
           }
         // JOptionPane.showMessageDialog(rootPane,"Tabla actualizada");
           rs.close();
           at.close();
       }catch(Exception a){
           JOptionPane.showMessageDialog(rootPane,"No se pudo actualizar");
       }
   }

public void consultaError(JComboBox CBTError)
{
     java.sql.Connection conectar = null;    
        PreparedStatement pst = null;
        ResultSet result = null;
        String SSQL = "SELECT id_error, nombre_error FROM Banco.tipoerror ORDER BY id_error ASC";
        
        try 
        {
            //Establecemos conexión con la BD 
            conectar = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco", user, pass);
            //Preparamos la consulta SQL
            pst = conectar.prepareStatement(SSQL);
            //Ejecutamos la consulta
            result = pst.executeQuery(); 
            //LLenamos nuestro ComboBox
            CBTError.addItem("Seleccione una opción");

            while(result.next())
            {
                CBTError.addItem(result.getString("id_error")+ "-"+result.getString("nombre_error"));
                

            }
        }
        catch (SQLException error) 
        {
            JOptionPane.showMessageDialog(null, error);
    
        }   
        finally
        {
            if(conectar!=null)
            {
                try
                {
                    conectar.close();
                    result.close();

                    conectar=null;
                    result=null;

                } 
                catch (SQLException error2) 
                {

                    JOptionPane.showMessageDialog(null, error2);
                }
            }

        }

    
}
public void consultaTransaccion( JComboBox CBTransaccion)
{
     java.sql.Connection conectar = null;    
        PreparedStatement pst = null;
        ResultSet result = null;
        String SSQL = "SELECT id_tipo, nombre_tipo FROM Banco.tipotransacciones ORDER BY id_tipo ASC";
        
        try 
        {
            //Establecemos conexión con la BD 
            conectar = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco", user, pass);
            //Preparamos la consulta SQL
            pst = conectar.prepareStatement(SSQL);
            //Ejecutamos la consulta
            result = pst.executeQuery(); 
            //LLenamos nuestro ComboBox
            CBTransaccion.addItem("Seleccione una opción");

            while(result.next())
            {
                CBTransaccion.addItem(result.getString("id_tipo")+ "-"+result.getString("nombre_tipo"));
                

            }
        }
        catch (SQLException error) 
        {
            JOptionPane.showMessageDialog(null, error);
    
        }   
        finally
        {
            if(conectar!=null)
            {
                try
                {
                    conectar.close();
                    result.close();

                    conectar=null;
                    result=null;

                } 
                catch (SQLException error2) 
                {

                    JOptionPane.showMessageDialog(null, error2);
                }
            }

        }
}

 public void consulta_Suc(JComboBox CBSucursal)
    {
        java.sql.Connection conectar = null;    
        PreparedStatement pst = null;
        ResultSet result = null;
        String SSQL = "SELECT idsucursal, nombre_sucursal FROM Banco.sucursal ORDER BY idsucursal ASC";
        
        try 
        {
            //Establecemos conexión con la BD 
            conectar = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco", user, pass);
            //Preparamos la consulta SQL
            pst = conectar.prepareStatement(SSQL);
            //Ejecutamos la consulta
            result = pst.executeQuery(); 
            //LLenamos nuestro ComboBox
            CBSucursal.addItem("Seleccione una opción");

            while(result.next())
            {
                CBSucursal.addItem(result.getString("idsucursal")+ "-"+result.getString("nombre_sucursal"));
                

            }
        }
        catch (SQLException error) 
        {
            JOptionPane.showMessageDialog(null, error);
    
        }   
        finally
        {
            if(conectar!=null)
            {
                try
                {
                    conectar.close();
                    result.close();

                    conectar=null;
                    result=null;

                } 
                catch (SQLException error2) 
                {

                    JOptionPane.showMessageDialog(null, error2);
                }
            }

        }
    }
 public void consultar_cuentas(JComboBox CBOrigen, JComboBox CBDestino)
    {
        java.sql.Connection conectar = null;    
        PreparedStatement pst = null;
        ResultSet result = null;
        String SSQL = "SELECT clabe,no_tarjeta,cl.nombre_cliente, c.saldo FROM banco.cuenta as c INNER JOIN banco.cliente as cl ON c.id_cliente = cl.id_cliente";
        try 
        {
            //Establecemos conexión con la BD 
            conectar = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco", user, pass);
            //Preparamos la consulta SQL
            pst = conectar.prepareStatement(SSQL);
            //Ejecutamos la consulta
            result = pst.executeQuery(); 
            //LLenamos nuestro ComboBox
            CBDestino.addItem("Seleccione una opción");
            CBOrigen.addItem("Seleccione una opción");

            while(result.next())
            {
                CBDestino.addItem(result.getString("clabe")+ "-" +result.getString("nombre_cliente"));
                CBOrigen.addItem(result.getString("clabe")+ "-" +result.getString("nombre_cliente"));

            }
        }
        catch (SQLException error) 
        {
            JOptionPane.showMessageDialog(null, error);
    
        }   
        finally
        {
            if(conectar!=null)
            {
                try
                {
                    conectar.close();
                    result.close();

                    conectar=null;
                    result=null;

                } 
                catch (SQLException error2) 
                {

                    JOptionPane.showMessageDialog(null, error2);
                }
            }

        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        CBOrigen = new javax.swing.JComboBox<>();
        CBSucursal = new javax.swing.JComboBox<>();
        CBTError = new javax.swing.JComboBox<>();
        CBTransaccion = new javax.swing.JComboBox<>();
        CBDestino = new javax.swing.JComboBox<>();
        BTAgrega = new javax.swing.JButton();
        BtModifica = new javax.swing.JButton();
        BTEliminar = new javax.swing.JButton();
        TFMonto = new javax.swing.JTextField();
        TFSpei = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        TTransfer = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jLabel1.setText("SPEI");

        jLabel2.setText("CLABE origen");

        jLabel3.setText("Sucursal");

        jLabel4.setText("Tipo Error");

        jLabel5.setText("Monto");

        jLabel6.setText("Transacción");

        jLabel7.setText("CLABE Destino ");

        BTAgrega.setText("Agregar");
        BTAgrega.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTAgregaActionPerformed(evt);
            }
        });

        BtModifica.setText("Modificar");
        BtModifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtModificaActionPerformed(evt);
            }
        });

        BTEliminar.setText("Eliminar");
        BTEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTEliminarActionPerformed(evt);
            }
        });

        TTransfer.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TTransfer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TTransferMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TTransfer);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(52, 52, 52)
                        .addComponent(TFSpei)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel6))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel7))))
                        .addGap(27, 27, 27))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(BTAgrega)
                        .addGap(340, 340, 340))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(CBOrigen, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4))
                                .addGap(27, 27, 27)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CBSucursal, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(CBTError, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(TFMonto, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CBDestino, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CBTransaccion, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(255, 255, 255)
                        .addComponent(BtModifica)
                        .addGap(82, 82, 82)
                        .addComponent(BTEliminar))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 592, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(TFSpei, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(CBTransaccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(CBOrigen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(CBSucursal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(CBDestino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(CBTError, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TFMonto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTAgrega)
                    .addComponent(BtModifica)
                    .addComponent(BTEliminar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(78, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BTAgregaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTAgregaActionPerformed
        // TODO add your handling code here:
        
         try{
            String aux2=(String)CBOrigen.getSelectedItem();
            String [] origen=aux2.split("-");
            
            String aux3=(String)CBDestino.getSelectedItem();
            String [] destino=aux3.split("-");
            
            String aux4=(String)CBSucursal.getSelectedItem();
            String [] sucursal=aux4.split("-");
            
            String aux5=(String)CBTError.getSelectedItem();
            String [] error=aux5.split("-");
            
            String aux6=(String)CBTransaccion.getSelectedItem();
            String [] transaccion=aux6.split("-");
            
            Statement st = con.createStatement();
            String sql = "INSERT INTO BANCO.transferencia(codigo_spei, idsucursal, id_error, id_tipo, clabe_origen, clabe_destino, monto)"
            + "VALUES('"+ TFSpei.getText() + "' , '" +sucursal[0]+ "' , '" + error[0] + "' , '" + transaccion[0] + "' ,'" + origen[0] + "' , '" + destino[0] + "','"+ TFMonto.getText()+"' )";

            st.executeUpdate(sql);
            st.close();
            //JOptionPane.showMessageDialog(null,"Se insertó correctamente");
            fillTabla();
            limpia();

        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al insertar"+e);
        }
    }//GEN-LAST:event_BTAgregaActionPerformed

    private void TTransferMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TTransferMouseClicked
        // TODO add your handling code here:
         String aux2=(String)CBOrigen.getSelectedItem();
        String [] cliente=aux2.split("-");
 
        int col = TTransfer.getSelectedRow();
       
        TFMonto.setText(TTransfer.getModel().getValueAt(col, 7).toString());
        TFSpei.setText(TTransfer.getModel().getValueAt(col, 1).toString());
      
    }//GEN-LAST:event_TTransferMouseClicked

    private void BtModificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtModificaActionPerformed
        // TODO add your handling code here:
        
          try{
            String aux2=(String)CBOrigen.getSelectedItem();
            String [] origen=aux2.split("-");
            
            String aux3=(String)CBDestino.getSelectedItem();
            String [] destino=aux3.split("-");
            
            String aux4=(String)CBSucursal.getSelectedItem();
            String [] sucursal=aux4.split("-");
            
            String aux5=(String)CBTError.getSelectedItem();
            String [] error=aux5.split("-");
            
            String aux6=(String)CBTransaccion.getSelectedItem();
            String [] transaccion=aux6.split("-");
         
            Statement st = con.createStatement();
            int fila = TTransfer.getSelectedRow();
            int id = Integer.parseInt(this.TTransfer.getValueAt(fila,0).toString());
           String sql = "UPDATE BANCO.transferencia SET codigo_spei = '"+ TFSpei.getText()+ "' , idsucursal = '"+ sucursal[0] + "' , id_error = '" + error[0] 
                   +"' , id_tipo ='" + transaccion[0] + "', clabe_origen  ='" + origen[0] + "' , clabe_destino = '"+ destino[0] + "', monto = '"+ TFMonto.getText() + "'   WHERE num_transferencia =  '"+id+"' ";         
            
         //String sql = "INSERT INTO BANCO.transferencia(codigo_spei, idsucursal, id_error, id_tipo, clabe_origen, clabe_destino, monto)"
          //  + "VALUES('"+ TFSpei.getText() + "' , '" +sucursal[0]+ "' , '" + error[0] + "' , '" + transaccion[0] + "' ,'" + origen[0] + "' , '" + destino[0] + "','"+ TFMonto.getText()+"' )";

            st.executeUpdate(sql);
            st.close();
            fillTabla(); 
            limpia();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al modificar:"+e);
        }
    }//GEN-LAST:event_BtModificaActionPerformed

    private void BTEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTEliminarActionPerformed
        // TODO add your handling code here:
         try{
            Statement st = con.createStatement();
            int fila = TTransfer.getSelectedRow();
            int id = Integer.parseInt(this.TTransfer.getValueAt(fila,0).toString());

            String sql="DELETE FROM BANCO.transferencia  WHERE num_transferencia =  '"+id+"' ";
            st.executeUpdate(sql);
            st.close();
            fillTabla();

            limpia();
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Error al eliminar:"+e);
        }
    }//GEN-LAST:event_BTEliminarActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_formWindowClosed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        fillTabla();
    }//GEN-LAST:event_formWindowActivated

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Transferencia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Transferencia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Transferencia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Transferencia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Transferencia().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTAgrega;
    private javax.swing.JButton BTEliminar;
    private javax.swing.JButton BtModifica;
    private javax.swing.JComboBox<String> CBDestino;
    private javax.swing.JComboBox<String> CBOrigen;
    private javax.swing.JComboBox<String> CBSucursal;
    private javax.swing.JComboBox<String> CBTError;
    private javax.swing.JComboBox<String> CBTransaccion;
    private javax.swing.JTextField TFMonto;
    private javax.swing.JTextField TFSpei;
    private javax.swing.JTable TTransfer;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
