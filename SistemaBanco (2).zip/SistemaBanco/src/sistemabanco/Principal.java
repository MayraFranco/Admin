/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemabanco;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author mayra
 */
public class Principal extends javax.swing.JFrame {

    /**
     * Creates new form Principal
     */
    public Principal() {
        initComponents();
         estableceConexion();
        
         modelo_tabla();
         modelo_tablaSuc();
        fillTabla();
    }
    Connection con;
    String pass = "postgres";
    String user = "postgres";
    ResultSet resultado = null;
    int filasel=0;
    int idsel=0;
    DefaultTableModel modelo = new DefaultTableModel();
public void estableceConexion()
    {
         try{
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco",user,pass);
          // JOptionPane.showMessageDialog(null,"Conexion Realizada");
           
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Error conexion" + ex);
        }
    }

public void modelo_tabla()
   {
       modelo.addColumn("id_clientes");
       modelo.addColumn("nombre_cliente");
       modelo.addColumn("telefono");
       modelo.addColumn("fecha_nacimiento");

       jTablaCliente.setModel(modelo);
   }
public void modelo_tablaSuc()
   {
       
       modelo.addColumn("idSucursal");
       modelo.addColumn("nombre_Sucursal");
       modelo.addColumn("ciudad");
       modelo.addColumn("activos");
        jTablaSucursal.setModel(modelo);
       
   }
public void limpia()
   {
       TextFieldNomCliente.setText(""); 
       TextFieldTel.setText("");
       //jCalendar .setText("");
    }
public void fillTabla()
   {
       modelo.setRowCount(0);
       String datos[] = new String[4]; //campos de la tabla
       
       try{
           Statement at = con.createStatement();
           ResultSet rs = at.executeQuery("SELECT * FROM BANCO.cliente"); // cambias a tu tabla
           
           while(rs.next())
           {
               datos[0] = rs.getString("id_cliente");
               datos[1] = rs.getString("nombre_cliente");
               datos[2] = rs.getString("telefono");
               datos[3] = rs.getString("fecha_nacimiento");
               modelo.addRow(datos);
           }
         // JOptionPane.showMessageDialog(rootPane,"Tabla actualizada");
           rs.close();
           at.close();
       }catch(Exception a){
           JOptionPane.showMessageDialog(rootPane,"No se pudo actualizar");
       }
        modelo.setRowCount(0);
       
       try{
           Statement at = con.createStatement();
           ResultSet rs = at.executeQuery("SELECT * FROM BANCO.sucursal"); // cambias a tu tabla
          
           while(rs.next())
           {
               datos[0] = rs.getString("idSucursal");
               datos[1] = rs.getString("nombre_sucursal");
               datos[2] = rs.getString("ciudad");
               datos[3] = rs.getString("activos");
               modelo.addRow(datos);
           }
           jTablaCliente.setModel(modelo);
          //JOptionPane.showMessageDialog(rootPane,"Tabla actualizada");
           rs.close();
           at.close();
       }catch(Exception a){
           JOptionPane.showMessageDialog(rootPane,"No se pudo actualizar");
       }
   }


    public void consultar_cuentas(JComboBox jComboBoxCLABE)
    {
        java.sql.Connection conectar = null;    
        PreparedStatement pst = null;
        ResultSet result = null;
        String SSQL = "SELECT clabe FROM Banco.cuenta ORDER BY clabe ASC";
        try 
        {
            //Establecemos conexión con la BD 
            conectar = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaBanco", user, pass);
            //Preparamos la consulta SQL
            pst = conectar.prepareStatement(SSQL);
            //Ejecutamos la consulta
            result = pst.executeQuery(); 
            //LLenamos nuestro ComboBox
            jComboBoxCLABE.addItem("Seleccione una opción");

            while(result.next())
            {
                jComboBoxCLABE.addItem(result.getString("clabe"));

            }
        }
        catch (SQLException error) 
        {
            JOptionPane.showMessageDialog(null, error);
    
        }   
        finally
        {
            if(conectar!=null)
            {
                try
                {
                    conectar.close();
                    result.close();

                    conectar=null;
                    result=null;

                } 
                catch (SQLException error2) 
                {

                    JOptionPane.showMessageDialog(null, error2);
                }
            }

        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel8 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        LabelNCliente = new javax.swing.JLabel();
        TextFieldNomCliente = new javax.swing.JTextField();
        labelTel = new javax.swing.JLabel();
        TextFieldTel = new javax.swing.JTextField();
        LabeFechaNac = new javax.swing.JLabel();
        jCalendar = new com.toedter.calendar.JCalendar();
        BotonAgrega = new javax.swing.JButton();
        BotonModifica = new javax.swing.JButton();
        BotonElimina = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTablaCliente = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        TablaSucursal = new javax.swing.JScrollPane();
        jTablaSucursal = new javax.swing.JTable();
        TextFieldSucursal = new javax.swing.JTextField();
        LabelNombreErr = new javax.swing.JLabel();
        LabelNombreErr1 = new javax.swing.JLabel();
        TextFieldCiudad = new javax.swing.JTextField();
        LabelNombreErr2 = new javax.swing.JLabel();
        TextFieldActivos = new javax.swing.JTextField();
        jToggleModificar = new javax.swing.JToggleButton();
        jToggleAgregar1 = new javax.swing.JToggleButton();
        jToggleButton4 = new javax.swing.JToggleButton();
        jPanel10 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        btnAddMaterial = new javax.swing.JButton();
        btnDelMaterial = new javax.swing.JButton();
        btnModMaterial = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtNombreMaterial = new javax.swing.JTextField();
        txtPrecioMaterial = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        JTMateriales = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        txtBuscaCliente = new javax.swing.JTextField();
        btnBuscaCliente = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtNombreVenta = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        txtTelVenta = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        txtEmailVenta = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTableVenta = new javax.swing.JTable();
        btnAddVenta = new javax.swing.JButton();
        btnModVenta = new javax.swing.JButton();
        btnDelVenta = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jTextField14 = new javax.swing.JTextField();
        BuscaProveedor = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        txtNombreCompra = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        txtRFCCompra = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        txtDirCompra = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        txtEmailCompra = new javax.swing.JTextField();
        btnAddCompra = new javax.swing.JButton();
        btnModCompra = new javax.swing.JButton();
        btnDelCompra = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTableCompra = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        cbIdCompra = new javax.swing.JComboBox<>();
        cbIdMaterial = new javax.swing.JComboBox<>();
        btnAddDetaCompra = new javax.swing.JButton();
        btnModDetalCompra = new javax.swing.JButton();
        btnDelDetaCompra = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTableDetalleCompra = new javax.swing.JTable();
        jTextField1 = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        btnAddMaterialProd = new javax.swing.JButton();
        btnModMateProduccion = new javax.swing.JButton();
        btnDelMatProduccion = new javax.swing.JButton();
        jScrollPane11 = new javax.swing.JScrollPane();
        jTableMaterialProduccion = new javax.swing.JTable();
        jTextcantidadprodprod = new javax.swing.JTextField();
        cbIdProduccionMaterial = new javax.swing.JComboBox<>();
        cbMaterialProduccion = new javax.swing.JComboBox<>();
        jPanel6 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        btnAddProduccion = new javax.swing.JButton();
        btnModProduccion = new javax.swing.JButton();
        btnDelProduccion = new javax.swing.JButton();
        jScrollPane10 = new javax.swing.JScrollPane();
        jTableProduccion = new javax.swing.JTable();
        jTextcantidadprod = new javax.swing.JTextField();
        cbProductoProducción = new javax.swing.JComboBox<>();
        jPanel14 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jScrollPane12 = new javax.swing.JScrollPane();
        jTableConsulta = new javax.swing.JTable();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel26 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jTabbedPane1StateChanged(evt);
            }
        });
        jTabbedPane1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jTabbedPane1PropertyChange(evt);
            }
        });

        jTabbedPane2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane2MouseClicked(evt);
            }
        });

        jLabel5.setText("R E G I S T R O ");

        LabelNCliente.setText("Nombre del Cliente");

        labelTel.setText("Telefono");

        LabeFechaNac.setText("Fecha Nacimiento");

        BotonAgrega.setText("Agregar");
        BotonAgrega.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonAgregaActionPerformed(evt);
            }
        });

        BotonModifica.setText("Modificar");
        BotonModifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonModificaActionPerformed(evt);
            }
        });

        BotonElimina.setText("Eliminar");
        BotonElimina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonEliminaActionPerformed(evt);
            }
        });

        jTablaCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTablaCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablaClienteMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(jTablaCliente);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(0, 82, Short.MAX_VALUE)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(305, 305, 305)
                                .addComponent(jLabel5))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel8Layout.createSequentialGroup()
                                        .addComponent(LabelNCliente)
                                        .addGap(77, 77, 77)
                                        .addComponent(TextFieldNomCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 324, Short.MAX_VALUE))
                                    .addGroup(jPanel8Layout.createSequentialGroup()
                                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(labelTel)
                                            .addComponent(LabeFechaNac))
                                        .addGap(83, 83, 83)
                                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel8Layout.createSequentialGroup()
                                                .addComponent(jCalendar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, Short.MAX_VALUE))
                                            .addComponent(TextFieldTel))))))
                        .addGap(132, 132, 132)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(BotonModifica, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
                            .addComponent(BotonAgrega, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(BotonElimina, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(117, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelNCliente)
                    .addComponent(TextFieldNomCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BotonAgrega))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelTel)
                            .addComponent(TextFieldTel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(BotonModifica)))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabeFechaNac)
                            .addComponent(jCalendar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(BotonElimina)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(270, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Cliente", jPanel8);

        jTablaSucursal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTablaSucursal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablaSucursalMouseClicked(evt);
            }
        });
        TablaSucursal.setViewportView(jTablaSucursal);

        TextFieldSucursal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldSucursalActionPerformed(evt);
            }
        });

        LabelNombreErr.setText("Nombre de la sucursal");
        LabelNombreErr.setName(""); // NOI18N

        LabelNombreErr1.setText("Ciudad");
        LabelNombreErr1.setName(""); // NOI18N

        LabelNombreErr2.setText("Activos ");
        LabelNombreErr2.setName(""); // NOI18N

        TextFieldActivos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldActivosActionPerformed(evt);
            }
        });

        jToggleModificar.setText("Modificar");
        jToggleModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleModificarActionPerformed(evt);
            }
        });

        jToggleAgregar1.setText("Agregar");
        jToggleAgregar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleAgregar1ActionPerformed(evt);
            }
        });

        jToggleButton4.setText("Eliminar ");
        jToggleButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LabelNombreErr)
                    .addComponent(LabelNombreErr1)
                    .addComponent(LabelNombreErr2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 19, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(TextFieldCiudad)
                        .addGap(56, 56, 56))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(TextFieldSucursal, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 519, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(TextFieldActivos, javax.swing.GroupLayout.DEFAULT_SIZE, 597, Short.MAX_VALUE)
                        .addGap(58, 58, 58)))
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jToggleButton4)
                    .addComponent(jToggleAgregar1)
                    .addComponent(jToggleModificar))
                .addContainerGap(21, Short.MAX_VALUE))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(TablaSucursal, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelNombreErr)
                    .addComponent(TextFieldSucursal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jToggleAgregar1))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelNombreErr1)
                    .addComponent(TextFieldCiudad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jToggleModificar))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(LabelNombreErr2)
                        .addComponent(TextFieldActivos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jToggleButton4))
                .addGap(30, 30, 30)
                .addComponent(TablaSucursal, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(355, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Sucursal", jPanel9);

        jLabel10.setText("Registro");

        btnAddMaterial.setText("Agregar");
        btnAddMaterial.setBorder(null);
        btnAddMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddMaterialActionPerformed(evt);
            }
        });

        btnDelMaterial.setText("Eliminar");
        btnDelMaterial.setBorder(null);
        btnDelMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelMaterialActionPerformed(evt);
            }
        });

        btnModMaterial.setText("Modificar");
        btnModMaterial.setBorder(null);
        btnModMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModMaterialActionPerformed(evt);
            }
        });

        jLabel12.setText("Precio");

        jLabel13.setText("Nombre");

        jLabel14.setText("Materiales Registrados");

        JTMateriales.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "IdMaterial", "Nombre", "Precio", "Existencia"
            }
        ));
        JTMateriales.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JTMaterialesMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(JTMateriales);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(286, 286, 286)
                        .addComponent(jLabel10))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(129, 129, 129)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel10Layout.createSequentialGroup()
                                    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnAddMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel10Layout.createSequentialGroup()
                                            .addGap(116, 116, 116)
                                            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(btnModMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGap(9, 9, 9)
                                    .addComponent(btnDelMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(33, 33, 33))
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                                        .addComponent(txtNombreMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(52, 52, 52))
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(155, 155, 155)))
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtPrecioMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(103, 103, 103)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addGap(26, 26, 26)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGap(55, 55, 55))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombreMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPrecioMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)))
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnModMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDelMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(305, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Cuenta", jPanel10);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );

        jTabbedPane1.addTab("Captura", jPanel1);

        jPanel12.setBackground(new java.awt.Color(153, 204, 255));

        txtBuscaCliente.setText("Busca el cliente...");
        txtBuscaCliente.setName(""); // NOI18N

        btnBuscaCliente.setBackground(new java.awt.Color(51, 153, 255));
        btnBuscaCliente.setText("Buscar");
        btnBuscaCliente.setBorder(null);
        btnBuscaCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscaClienteActionPerformed(evt);
            }
        });

        jLabel1.setText("Nombre");

        jLabel24.setText("Teléfono");

        jLabel25.setText("Email");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(txtBuscaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addComponent(btnBuscaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGap(73, 73, 73)
                                .addComponent(jLabel1))
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtTelVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNombreVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtEmailVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel12Layout.createSequentialGroup()
                                        .addGap(32, 32, 32)
                                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel24)
                                            .addComponent(jLabel25))))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBuscaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscaCliente))
                .addGap(26, 26, 26)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNombreVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtTelVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtEmailVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTableVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "idVenta", "Nombre", "Teléfono", "Email", "Visitas"
            }
        ));
        jTableVenta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableVentaMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(jTableVenta);

        btnAddVenta.setBackground(new java.awt.Color(51, 153, 255));
        btnAddVenta.setText("Agregar");
        btnAddVenta.setBorder(null);
        btnAddVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddVentaActionPerformed(evt);
            }
        });

        btnModVenta.setBackground(new java.awt.Color(51, 153, 255));
        btnModVenta.setText("Modificar");
        btnModVenta.setBorder(null);
        btnModVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModVentaActionPerformed(evt);
            }
        });

        btnDelVenta.setBackground(new java.awt.Color(51, 153, 255));
        btnDelVenta.setText("Eliminar");
        btnDelVenta.setBorder(null);
        btnDelVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelVentaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnModVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDelVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAddVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 581, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 348, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addComponent(btnAddVenta)
                .addGap(39, 39, 39)
                .addComponent(btnModVenta)
                .addGap(44, 44, 44)
                .addComponent(btnDelVenta)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Préstamos", jPanel2);

        jPanel13.setBackground(new java.awt.Color(153, 204, 255));

        jTextField14.setText("Busca el Proveedor...");

        BuscaProveedor.setBackground(new java.awt.Color(51, 153, 255));
        BuscaProveedor.setText("Buscar");
        BuscaProveedor.setBorder(null);
        BuscaProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscaProveedorActionPerformed(evt);
            }
        });

        jLabel27.setText("Nombre");

        jLabel28.setText("RFC");

        jLabel29.setText("Dirección");

        jLabel30.setText("Email");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(BuscaProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(73, 73, 73)
                                .addComponent(jLabel27))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtRFCCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNombreCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtDirCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtEmailCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel13Layout.createSequentialGroup()
                                        .addGap(32, 32, 32)
                                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel28)
                                            .addComponent(jLabel29)
                                            .addComponent(jLabel30))))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BuscaProveedor))
                .addGap(26, 26, 26)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNombreCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtRFCCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtDirCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtEmailCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(490, Short.MAX_VALUE))
        );

        btnAddCompra.setBackground(new java.awt.Color(51, 153, 255));
        btnAddCompra.setText("Agregar");
        btnAddCompra.setBorder(null);
        btnAddCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddCompraActionPerformed(evt);
            }
        });

        btnModCompra.setBackground(new java.awt.Color(51, 153, 255));
        btnModCompra.setText("Modificar");
        btnModCompra.setBorder(null);
        btnModCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModCompraActionPerformed(evt);
            }
        });

        btnDelCompra.setBackground(new java.awt.Color(51, 153, 255));
        btnDelCompra.setText("Eliminar");
        btnDelCompra.setBorder(null);
        btnDelCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelCompraActionPerformed(evt);
            }
        });

        jTableCompra.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "idCompra", "Nombre", "RFC", "Dirección", "Email"
            }
        ));
        jTableCompra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableCompraMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(jTableCompra);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnModCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDelCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAddCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 537, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addComponent(btnAddCompra)
                .addGap(39, 39, 39)
                .addComponent(btnModCompra)
                .addGap(44, 44, 44)
                .addComponent(btnDelCompra)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Transferencias", jPanel4);

        jPanel5.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jPanel5MouseMoved(evt);
            }
        });

        jLabel31.setText("IdCompra");

        jLabel32.setText("IdMaterial");

        jLabel33.setText("Cantidad");

        cbIdCompra.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbIdMaterial.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnAddDetaCompra.setBackground(new java.awt.Color(51, 153, 255));
        btnAddDetaCompra.setText("Agregar");
        btnAddDetaCompra.setBorder(null);
        btnAddDetaCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddDetaCompraActionPerformed(evt);
            }
        });

        btnModDetalCompra.setBackground(new java.awt.Color(51, 153, 255));
        btnModDetalCompra.setText("Modificar");
        btnModDetalCompra.setBorder(null);
        btnModDetalCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModDetalCompraActionPerformed(evt);
            }
        });

        btnDelDetaCompra.setBackground(new java.awt.Color(51, 153, 255));
        btnDelDetaCompra.setText("Eliminar");
        btnDelDetaCompra.setBorder(null);
        btnDelDetaCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelDetaCompraActionPerformed(evt);
            }
        });

        jTableDetalleCompra.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableDetalleCompra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableDetalleCompraMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(jTableDetalleCompra);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 531, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbIdCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGap(27, 27, 27)
                                        .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGap(24, 24, 24)
                                        .addComponent(cbIdMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(btnAddDetaCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 243, Short.MAX_VALUE)
                                .addComponent(btnModDetalCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(101, 101, 101)))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnDelDetaCompra, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.LEADING))
                        .addContainerGap(238, Short.MAX_VALUE))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel33)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel31)
                            .addComponent(jLabel32))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbIdMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbIdCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(50, 50, 50)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddDetaCompra)
                    .addComponent(btnModDetalCompra)
                    .addComponent(btnDelDetaCompra))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Depósitos", jPanel5);

        jPanel7.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jPanel7MouseMoved(evt);
            }
        });

        jLabel35.setText("IdProducción");

        jLabel37.setText("Material");

        jLabel38.setText("Cantidad");

        btnAddMaterialProd.setBackground(new java.awt.Color(51, 153, 255));
        btnAddMaterialProd.setText("Agregar");
        btnAddMaterialProd.setBorder(null);
        btnAddMaterialProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddMaterialProdActionPerformed(evt);
            }
        });

        btnModMateProduccion.setBackground(new java.awt.Color(51, 153, 255));
        btnModMateProduccion.setText("Modificar");
        btnModMateProduccion.setBorder(null);
        btnModMateProduccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModMateProduccionActionPerformed(evt);
            }
        });

        btnDelMatProduccion.setBackground(new java.awt.Color(51, 153, 255));
        btnDelMatProduccion.setText("Eliminar");
        btnDelMatProduccion.setBorder(null);
        btnDelMatProduccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelMatProduccionActionPerformed(evt);
            }
        });

        jTableMaterialProduccion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableMaterialProduccion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableMaterialProduccionMouseClicked(evt);
            }
        });
        jScrollPane11.setViewportView(jTableMaterialProduccion);

        cbIdProduccionMaterial.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbMaterialProduccion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(btnAddMaterialProd, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 389, Short.MAX_VALUE)
                        .addComponent(btnModMateProduccion, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(91, 91, 91)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnDelMatProduccion, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(105, 105, 105))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbIdProduccionMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel35, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(101, 101, 101))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                .addComponent(cbMaterialProduccion, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(53, 53, 53)))
                        .addComponent(jTextcantidadprodprod, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(82, 82, 82))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel38)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextcantidadprodprod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel35)
                            .addComponent(jLabel37))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbIdProduccionMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbMaterialProduccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(50, 50, 50)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddMaterialProd)
                    .addComponent(btnModMateProduccion)
                    .addComponent(btnDelMatProduccion))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(168, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Errores", jPanel7);

        jLabel34.setText("Producto");

        jLabel36.setText("Cantidad");

        btnAddProduccion.setBackground(new java.awt.Color(51, 153, 255));
        btnAddProduccion.setText("Agregar");
        btnAddProduccion.setBorder(null);
        btnAddProduccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddProduccionActionPerformed(evt);
            }
        });

        btnModProduccion.setBackground(new java.awt.Color(51, 153, 255));
        btnModProduccion.setText("Modificar");
        btnModProduccion.setBorder(null);
        btnModProduccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModProduccionActionPerformed(evt);
            }
        });

        btnDelProduccion.setBackground(new java.awt.Color(51, 153, 255));
        btnDelProduccion.setText("Eliminar");
        btnDelProduccion.setBorder(null);
        btnDelProduccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelProduccionActionPerformed(evt);
            }
        });

        jTableProduccion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableProduccion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableProduccionMouseClicked(evt);
            }
        });
        jScrollPane10.setViewportView(jTableProduccion);

        cbProductoProducción.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jScrollPane10)
                        .addContainerGap())
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAddProduccion, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cbProductoProducción, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 235, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(btnModProduccion, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(83, 83, 83)
                                .addComponent(btnDelProduccion, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jTextcantidadprod, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(237, Short.MAX_VALUE))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(jLabel36))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextcantidadprod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(cbProductoProducción, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(42, 42, 42)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddProduccion)
                    .addComponent(btnModProduccion)
                    .addComponent(btnDelProduccion))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Transacciones", jPanel6);

        jButton1.setText("Buscar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTableConsulta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane12.setViewportView(jTableConsulta);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Total de las ventas de los clientes por fechas", "Informacion de los clientes  que realizaron una compra una fecha " }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel26.setText("Consulta 1");

        jLabel39.setText("Consulta 2");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addComponent(jLabel26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel39)
                        .addGap(176, 176, 176)
                        .addComponent(jButton1)
                        .addGap(199, 199, 199))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 746, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 565, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(133, Short.MAX_VALUE))))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jLabel39)
                    .addComponent(jLabel26))
                .addGap(129, 129, 129)
                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Consulta", jPanel14);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 894, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addGap(58, 58, 58))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTabbedPane1PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jTabbedPane1PropertyChange
   
    }//GEN-LAST:event_jTabbedPane1PropertyChange

    private void jTabbedPane1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jTabbedPane1StateChanged

    }//GEN-LAST:event_jTabbedPane1StateChanged

    private void jTableProduccionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableProduccionMouseClicked

        
    }//GEN-LAST:event_jTableProduccionMouseClicked

    private void btnDelProduccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelProduccionActionPerformed

       
    }//GEN-LAST:event_btnDelProduccionActionPerformed

    private void btnModProduccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModProduccionActionPerformed
       
    }//GEN-LAST:event_btnModProduccionActionPerformed

    private void btnAddProduccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddProduccionActionPerformed

        
    }//GEN-LAST:event_btnAddProduccionActionPerformed

    private void jPanel7MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel7MouseMoved
        
    }//GEN-LAST:event_jPanel7MouseMoved

    private void jTableMaterialProduccionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableMaterialProduccionMouseClicked

        
    }//GEN-LAST:event_jTableMaterialProduccionMouseClicked

    private void btnDelMatProduccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelMatProduccionActionPerformed
        
    }//GEN-LAST:event_btnDelMatProduccionActionPerformed

    private void btnModMateProduccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModMateProduccionActionPerformed
        
    }//GEN-LAST:event_btnModMateProduccionActionPerformed

    private void btnAddMaterialProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddMaterialProdActionPerformed

        
    }//GEN-LAST:event_btnAddMaterialProdActionPerformed

    private void jPanel5MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel5MouseMoved
     
    }//GEN-LAST:event_jPanel5MouseMoved

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTableDetalleCompraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableDetalleCompraMouseClicked

    }//GEN-LAST:event_jTableDetalleCompraMouseClicked

    private void btnDelDetaCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelDetaCompraActionPerformed

      
    }//GEN-LAST:event_btnDelDetaCompraActionPerformed

    private void btnModDetalCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModDetalCompraActionPerformed

    }//GEN-LAST:event_btnModDetalCompraActionPerformed

    private void btnAddDetaCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddDetaCompraActionPerformed

    }//GEN-LAST:event_btnAddDetaCompraActionPerformed

    private void jTableCompraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableCompraMouseClicked

    }//GEN-LAST:event_jTableCompraMouseClicked

    private void btnDelCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelCompraActionPerformed
       
    }//GEN-LAST:event_btnDelCompraActionPerformed

    private void btnModCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModCompraActionPerformed

     
    }//GEN-LAST:event_btnModCompraActionPerformed

    private void btnAddCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddCompraActionPerformed

        
    }//GEN-LAST:event_btnAddCompraActionPerformed

    private void BuscaProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscaProveedorActionPerformed
       
    }//GEN-LAST:event_BuscaProveedorActionPerformed

    private void btnDelVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelVentaActionPerformed

   
    }//GEN-LAST:event_btnDelVentaActionPerformed

    private void btnModVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModVentaActionPerformed

    }//GEN-LAST:event_btnModVentaActionPerformed

    private void btnAddVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddVentaActionPerformed

    }//GEN-LAST:event_btnAddVentaActionPerformed

    private void jTableVentaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableVentaMouseClicked

    }//GEN-LAST:event_jTableVentaMouseClicked

    private void btnBuscaClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscaClienteActionPerformed
        
    }//GEN-LAST:event_btnBuscaClienteActionPerformed

    private void jTabbedPane2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane2MouseClicked

    }//GEN-LAST:event_jTabbedPane2MouseClicked

    private void JTMaterialesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JTMaterialesMouseClicked

    }//GEN-LAST:event_JTMaterialesMouseClicked

    private void btnModMaterialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModMaterialActionPerformed

    }//GEN-LAST:event_btnModMaterialActionPerformed

    private void btnDelMaterialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelMaterialActionPerformed

    }//GEN-LAST:event_btnDelMaterialActionPerformed

    private void btnAddMaterialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddMaterialActionPerformed

    }//GEN-LAST:event_btnAddMaterialActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void BotonAgregaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonAgregaActionPerformed
        // TODO add your handling code here:
        try{

            Statement st = con.createStatement();
            String sql = "INSERT INTO BANCO.cliente(nombre_cliente, telefono, fecha_nacimiento)"
            + "VALUES( '"+TextFieldNomCliente.getText()+"'  , '"+TextFieldTel.getText()+"' ,'"+jCalendar.getDate()+"' )";

            st.executeUpdate(sql);
            st.close();
            JOptionPane.showMessageDialog(null,"Se insertó correctamente");
            fillTabla();
            limpia();

        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al insertar"+e);
        }
    }//GEN-LAST:event_BotonAgregaActionPerformed

    private void BotonModificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonModificaActionPerformed
        // TODO add your handling code here:
        try{
            int fila = jTablaCliente.getSelectedRow();
            int id = Integer.parseInt(this.jTablaCliente.getValueAt(fila,0).toString());
            Statement st = con.createStatement();
            String sql = "UPDATE BANCO.cliente SET nombre_cliente = '"+ TextFieldNomCliente.getText() +"' ,  telefono = '"+TextFieldTel.getText()+"' , fecha_nacimiento = '"+jCalendar.getDate()+"'  WHERE id_cliente =  '"+id+"' ";
            st.executeUpdate(sql);
            st.close();
            fillTabla();
            limpia();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al modificar:"+e);
        }
    }//GEN-LAST:event_BotonModificaActionPerformed

    private void BotonEliminaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonEliminaActionPerformed
        // TODO add your handling code here:
        try{
            Statement st = con.createStatement();
            int fila = jTablaCliente.getSelectedRow();
            int id = Integer.parseInt(this.jTablaCliente.getValueAt(fila,0).toString());

            String sql="DELETE FROM BANCO.cliente  WHERE id_cliente =  '"+id+"' ";
            st.executeUpdate(sql);
            st.close();
            fillTabla();

            limpia();
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Error al eliminar:"+e);
        }
    }//GEN-LAST:event_BotonEliminaActionPerformed

    private void jTablaClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablaClienteMouseClicked
        // TODO add your handling code here:
        int col = jTablaCliente.getSelectedRow();
        TextFieldNomCliente.setText(jTablaCliente.getModel().getValueAt(col, 1).toString());
        TextFieldTel.setText(jTablaCliente.getModel().getValueAt(col, 2).toString());
        //jCalendar.setText(jTablaCliente.getModel().getValueAt(col, 3).toString());
    }//GEN-LAST:event_jTablaClienteMouseClicked

    private void jTablaSucursalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablaSucursalMouseClicked
        // TODO add your handling code here:
        int col = jTablaSucursal.getSelectedRow();
        TextFieldSucursal.setText(jTablaSucursal.getModel().getValueAt(col, 1).toString());
        TextFieldCiudad.setText(jTablaSucursal.getModel().getValueAt(col, 2).toString());
        TextFieldActivos.setText(jTablaSucursal.getModel().getValueAt(col, 3).toString());

        //jCalendar.setText(jTablaCliente.getModel().getValueAt(col, 3).toString());
    }//GEN-LAST:event_jTablaSucursalMouseClicked

    private void TextFieldSucursalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldSucursalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldSucursalActionPerformed

    private void TextFieldActivosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldActivosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldActivosActionPerformed

    private void jToggleModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleModificarActionPerformed
        // TODO add your handling code here:
        try{
            float activos = Float.parseFloat(TextFieldActivos.getText());
            int fila = jTablaSucursal.getSelectedRow();
            int id = Integer.parseInt(this.jTablaSucursal.getValueAt(fila,0).toString());
            Statement st = con.createStatement();
            String sql = "UPDATE BANCO.sucursal SET nombre_sucursal = '"+ TextFieldSucursal.getText() +"' ,  ciudad = '"+TextFieldCiudad.getText()+"' , activos = '"+activos+"'  WHERE idSucursal =  '"+id+"' ";
            st.executeUpdate(sql);
            st.close();
            fillTabla();
            limpia();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al modificar:"+e);
        }
    }//GEN-LAST:event_jToggleModificarActionPerformed

    private void jToggleAgregar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleAgregar1ActionPerformed
        // TODO add your handling code here:
 try{
             float activos = Float.parseFloat(TextFieldActivos.getText());
                     
            Statement st = con.createStatement();
            String sql = "INSERT INTO BANCO.sucursal(nombre_sucursal, ciudad, activos)"
            + "VALUES( '"+TextFieldSucursal.getText()+"'  , '"+TextFieldCiudad.getText()+"' ,'"+activos+"' )";

            st.executeUpdate(sql);
            st.close();
           
            fillTabla();
            limpia();

        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al insertar"+e);
        }
    }//GEN-LAST:event_jToggleAgregar1ActionPerformed

    private void jToggleButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton4ActionPerformed
        // TODO add your handling code here:
        try{
            Statement st = con.createStatement();
            int fila = jTablaSucursal.getSelectedRow();
            int id = Integer.parseInt(this.jTablaSucursal.getValueAt(fila,0).toString());

            String sql="DELETE FROM BANCO.sucursal  WHERE idSucursal =  '"+id+"' ";
            st.executeUpdate(sql);
            st.close();
            fillTabla();

            limpia();
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Error al eliminar:"+e);
        }
    }//GEN-LAST:event_jToggleButton4ActionPerformed

    
    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonAgrega;
    private javax.swing.JButton BotonElimina;
    private javax.swing.JButton BotonModifica;
    private javax.swing.JButton BuscaProveedor;
    private javax.swing.JTable JTMateriales;
    private javax.swing.JLabel LabeFechaNac;
    private javax.swing.JLabel LabelNCliente;
    private javax.swing.JLabel LabelNombreErr;
    private javax.swing.JLabel LabelNombreErr1;
    private javax.swing.JLabel LabelNombreErr2;
    private javax.swing.JScrollPane TablaSucursal;
    private javax.swing.JTextField TextFieldActivos;
    private javax.swing.JTextField TextFieldCiudad;
    private javax.swing.JTextField TextFieldNomCliente;
    private javax.swing.JTextField TextFieldSucursal;
    private javax.swing.JTextField TextFieldTel;
    private javax.swing.JButton btnAddCompra;
    private javax.swing.JButton btnAddDetaCompra;
    private javax.swing.JButton btnAddMaterial;
    private javax.swing.JButton btnAddMaterialProd;
    private javax.swing.JButton btnAddProduccion;
    private javax.swing.JButton btnAddVenta;
    private javax.swing.JButton btnBuscaCliente;
    private javax.swing.JButton btnDelCompra;
    private javax.swing.JButton btnDelDetaCompra;
    private javax.swing.JButton btnDelMatProduccion;
    private javax.swing.JButton btnDelMaterial;
    private javax.swing.JButton btnDelProduccion;
    private javax.swing.JButton btnDelVenta;
    private javax.swing.JButton btnModCompra;
    private javax.swing.JButton btnModDetalCompra;
    private javax.swing.JButton btnModMateProduccion;
    private javax.swing.JButton btnModMaterial;
    private javax.swing.JButton btnModProduccion;
    private javax.swing.JButton btnModVenta;
    private javax.swing.JComboBox<String> cbIdCompra;
    private javax.swing.JComboBox<String> cbIdMaterial;
    private javax.swing.JComboBox<String> cbIdProduccionMaterial;
    private javax.swing.JComboBox<String> cbMaterialProduccion;
    private javax.swing.JComboBox<String> cbProductoProducción;
    private javax.swing.JButton jButton1;
    private com.toedter.calendar.JCalendar jCalendar;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTablaCliente;
    private javax.swing.JTable jTablaSucursal;
    private javax.swing.JTable jTableCompra;
    private javax.swing.JTable jTableConsulta;
    private javax.swing.JTable jTableDetalleCompra;
    private javax.swing.JTable jTableMaterialProduccion;
    private javax.swing.JTable jTableProduccion;
    private javax.swing.JTable jTableVenta;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextcantidadprod;
    private javax.swing.JTextField jTextcantidadprodprod;
    private javax.swing.JToggleButton jToggleAgregar1;
    private javax.swing.JToggleButton jToggleButton4;
    private javax.swing.JToggleButton jToggleModificar;
    private javax.swing.JLabel labelTel;
    private javax.swing.JTextField txtBuscaCliente;
    private javax.swing.JTextField txtDirCompra;
    private javax.swing.JTextField txtEmailCompra;
    private javax.swing.JTextField txtEmailVenta;
    private javax.swing.JTextField txtNombreCompra;
    private javax.swing.JTextField txtNombreMaterial;
    private javax.swing.JTextField txtNombreVenta;
    private javax.swing.JTextField txtPrecioMaterial;
    private javax.swing.JTextField txtRFCCompra;
    private javax.swing.JTextField txtTelVenta;
    // End of variables declaration//GEN-END:variables
}
